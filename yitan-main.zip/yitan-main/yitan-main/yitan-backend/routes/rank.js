const express = require('express');
const router = express.Router();

// Mock 榜单数据（后续可替换为数据库查询）
const MOCK_RANK_LIST = [
  {
    id: 1,
    rank: 1,
    name: "大众炒粉",
    img: "/images/icons/indexPage/大众炒粉.png",
    rating: 4.8,
    reviewCount: 128,
    tags: ["必吃榜", "炒粉"],
    distance: 500,
    avgPrice: 10,
    likeCount: 2200
  },
  {
    id: 2,
    rank: 2,
    name: "泰奶冰沙",
    img: "/images/icons/indexPage/泰奶冰沙.png",
    rating: 4.7,
    reviewCount: 96,
    tags: ["必吃榜", "饮品"],
    distance: 202,
    avgPrice: 18,
    likeCount: 1800
  },
  {
    id: 3,
    rank: 3,
    name: "土豆泥拌粉",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.6,
    reviewCount: 87,
    tags: ["必吃榜", "拌粉"],
    distance: 320,
    avgPrice: 14,
    likeCount: 1560
  },
  {
    id: 4,
    rank: 4,
    name: "阿强烧烤",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.5,
    reviewCount: 65,
    tags: ["烧烤"],
    distance: 240,
    avgPrice: 35,
    likeCount: 1340
  },
  {
    id: 5,
    rank: 5,
    name: "鲜切水果摊",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.4,
    reviewCount: 52,
    tags: ["水果", "生鲜"],
    distance: 120,
    avgPrice: 15,
    likeCount: 980
  },
  {
    id: 6,
    rank: 6,
    name: "韩式炸鸡档",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.3,
    reviewCount: 41,
    tags: ["炸物"],
    distance: 330,
    avgPrice: 22,
    likeCount: 890
  },
  {
    id: 7,
    rank: 7,
    name: "东北烤冷面（贝岗小摊店）",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.2,
    reviewCount: 38,
    tags: ["主食"],
    distance: 410,
    avgPrice: 12,
    likeCount: 760
  },
  {
    id: 8,
    rank: 8,
    name: "广式蒸点铺",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.1,
    reviewCount: 29,
    tags: ["蒸煮"],
    distance: 180,
    avgPrice: 16,
    likeCount: 650
  },
  {
    id: 9,
    rank: 9,
    name: "糖水铺子",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 4.0,
    reviewCount: 25,
    tags: ["甜品"],
    distance: 150,
    avgPrice: 14,
    likeCount: 580
  },
  {
    id: 10,
    rank: 10,
    name: "炸物研究所",
    img: "/images/icons/catogoryPage/摊位主图1.png",
    rating: 3.9,
    reviewCount: 20,
    tags: ["炸物"],
    distance: 160,
    avgPrice: 15,
    likeCount: 430
  }
];

/**
 * GET /api/getRankList?type=hot|rating|popular|value
 * 获取榜单列表
 */
router.get('/', (req, res) => {
  const type = req.query.type || 'hot';
  let list = [...MOCK_RANK_LIST];

  switch (type) {
    case 'hot':
      // 热门：likeCount 降序 + 必吃榜优先
      list.sort((a, b) => {
        const aHot = (a.tags || []).some(t => t.includes('必吃')) ? 10000 : 0;
        const bHot = (b.tags || []).some(t => t.includes('必吃')) ? 10000 : 0;
        return (bHot + b.likeCount) - (aHot + a.likeCount);
      });
      break;
    case 'rating':
      // 好评：rating 降序
      list.sort((a, b) => b.rating - a.rating);
      break;
    case 'popular':
      // 人气：likeCount 降序
      list.sort((a, b) => b.likeCount - a.likeCount);
      break;
    case 'value':
      // 实惠：avgPrice 升序
      list.sort((a, b) => a.avgPrice - b.avgPrice);
      break;
    default:
      break;
  }

  // 重新分配排名
  const ranked = list.map((item, index) => ({
    ...item,
    rank: index + 1
  }));

  res.json({
    code: 200,
    message: 'ok',
    data: {
      list: ranked
    }
  });
});

module.exports = router;
