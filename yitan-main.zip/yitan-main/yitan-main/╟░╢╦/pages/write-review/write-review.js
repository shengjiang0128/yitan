const { addReview } = require("../../utils/stall-reviews.js");
const { getStallById } = require("../../utils/category-data.js");

Page({
  data: {
    statusBarHeight: 20,
    stallId: "",
    stallName: "",
    stallCover: "",
    content: "",
    images: [],
    submitting: false,

    // 四维评分
    scoreDims: [
      { key: "taste", label: "味道" },
      { key: "service", label: "服务" },
      { key: "value", label: "性价比" },
      { key: "hygiene", label: "卫生" }
    ],
    scores: {
      taste: 0,
      service: 0,
      value: 0,
      hygiene: 0
    },
    allScored: false
  },

  onLoad(options) {
    const sys = wx.getWindowInfo();
    const stallId = options.stallId || "";
    const stall = getStallById(stallId);
    this.setData({
      statusBarHeight: sys.statusBarHeight,
      stallId: String(stallId),
      stallName: options.stallName
        ? decodeURIComponent(options.stallName)
        : stall
          ? stall.name
          : "小摊",
      stallCover: stall ? stall.img || stall.banner || "" : ""
    });
  },

  goBack() {
    wx.navigateBack();
  },

  onInput(e) {
    this.setData({ content: e.detail.value });
  },

  // 点击星星打分
  onRate(e) {
    const dim = e.currentTarget.dataset.dim;
    const val = e.currentTarget.dataset.val;
    const scores = { ...this.data.scores, [dim]: val };
    const allScored = Object.values(scores).every((v) => v > 0);
    this.setData({ scores, allScored });
  },

  onChooseImage() {
    const remain = 3 - this.data.images.length;
    if (remain <= 0) {
      wx.showToast({ title: "最多 3 张图片", icon: "none" });
      return;
    }
    wx.chooseMedia({
      count: remain,
      mediaType: ["image"],
      success: (res) => {
        const paths = (res.tempFiles || []).map((f) => f.tempFilePath);
        this.setData({ images: this.data.images.concat(paths).slice(0, 3) });
      }
    });
  },

  onRemoveImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images.slice();
    images.splice(index, 1);
    this.setData({ images });
  },

  onSubmit() {
    const { content, stallId, stallName, stallCover, submitting, scores } = this.data;
    if (submitting) return;
    if (!(content || "").trim()) {
      wx.showToast({ title: "写点评价再发布吧", icon: "none" });
      return;
    }
    if (!stallId) {
      wx.showToast({ title: "摊位信息缺失", icon: "none" });
      return;
    }

    // 校验评分
    const dims = ["taste", "service", "value", "hygiene"];
    for (const dim of dims) {
      if (!scores[dim] || scores[dim] < 1) {
        wx.showToast({ title: "请为所有维度打分后再发布", icon: "none" });
        return;
      }
    }

    this.setData({ submitting: true });
    addReview({
      stallId,
      stallName,
      stallCover,
      content: content.trim(),
      images: this.data.images,
      scores
    });

    wx.showToast({ title: "评价已发布", icon: "success" });
    setTimeout(() => {
      this.setData({ submitting: false });
      wx.navigateBack();
    }, 500);
  }
});
