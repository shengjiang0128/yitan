const { request, isApiOn } = require("../../utils/api-client.js");
const { getAllStalls } = require("../../utils/category-data.js");
const { getStallRating, toStarsOnly } = require("../../utils/stall-reviews.js");

Page({
  data: {
    statusBarHeight: 50,

    // Tab
    tabs: [
      { key: "hot", label: "热门榜单" },
      { key: "rating", label: "好评最多" },
      { key: "popular", label: "人气最高" },
      { key: "value", label: "实惠之选" }
    ],
    activeTab: 0,

    // 列表
    currentList: [],

    // Banner
    banners: [
      {
        id: 1,
        image: "/images/icons/indexPage/榜单.png",
        title: "一摊必吃榜"
      },
      {
        id: 2,
        image: "/images/icons/indexPage/榜单.png",
        title: "每周人气排行"
      }
    ]
  },

  onLoad() {
    const sys = wx.getWindowInfo();
    this.setData({ statusBarHeight: sys.statusBarHeight });
    this.loadRankData();
  },

  onShow() {
    // 每次回到页面刷新数据（可能新增了评价）
    this.loadRankData();
  },

  onPullDownRefresh() {
    this.loadRankData();
    wx.stopPullDownRefresh();
  },

  // ========= 数据加载 =========

  loadRankData() {
    // 尝试 API，失败则用本地数据
    if (isApiOn()) {
      this.fetchRankData();
    } else {
      this.buildLocalRankList();
    }
  },

  /** 后端接口回退 */
  fetchRankData() {
    request({ url: "/api/getRankList", method: "GET", auth: false })
      .then((res) => {
        if (res.data && res.data.code === 200 && res.data.data) {
          const apiList = res.data.data.list || res.data.data.rankList || [];
          if (apiList.length) {
            this.setData({ currentList: this.decorateList(apiList) });
            return;
          }
        }
        this.buildLocalRankList();
      })
      .catch(() => {
        console.log("榜单接口未就绪，使用本地数据");
        this.buildLocalRankList();
      });
  },

  /** 用本地 category-data 构建榜单 */
  buildLocalRankList() {
    const all = getAllStalls();
    if (!all || !all.length) {
      this.setData({ currentList: [] });
      return;
    }

    // 为每个摊位补充评分数据
    const enriched = all.map((stall) => {
      const rating = getStallRating(stall.id);
      const finalRating = rating.overall > 0 ? rating.overall : (stall.rating || 0);
      const starsText = rating.overall > 0
        ? toStarsOnly(rating.overall)
        : (stall.rating ? toStarsOnly(stall.rating) : "");
      return {
        ...stall,
        img: stall.img || stall.banner || "",
        rating: finalRating,
        ratingStars: starsText,
        reviewCount: rating.reviewCount || 0,
        likeCount: stall.likeCount || Math.floor(Math.random() * 3000) + 500,
        likeCountText: this.formatLikeCount(stall.likeCount || Math.floor(Math.random() * 3000) + 500),
        avgPrice: stall.avgPrice || Math.floor(Math.random() * 30) + 5,
        distance: stall.distance || Math.floor(Math.random() * 1000) + 50,
        tags: stall.tags || []
      };
    });

    const sorted = this.sortByTab(enriched, this.data.activeTab);
    const list = sorted.slice(0, 20).map((item, index) => ({
      ...item,
      rank: index + 1
    }));

    this.setData({ currentList: list });
  },

  // ========= Tab 切换 =========

  switchTab(e) {
    const index = e.currentTarget.dataset.index;
    if (index === this.data.activeTab) return;
    this.setData({ activeTab: index });
    this.loadRankData();
  },

  /** 按 tab 规则排序 */
  sortByTab(list, tabIndex) {
    const arr = [...list];
    switch (tabIndex) {
      case 0: // 热门：likeCount 降序 + 必吃榜优先
        arr.sort((a, b) => {
          const aHot = (a.tags || []).some((t) => t.includes("必吃")) ? 10000 : 0;
          const bHot = (b.tags || []).some((t) => t.includes("必吃")) ? 10000 : 0;
          return (bHot + (b.likeCount || 0)) - (aHot + (a.likeCount || 0));
        });
        break;
      case 1: // 好评：rating 降序
        arr.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 2: // 人气：likeCount 降序
        arr.sort((a, b) => (b.likeCount || 0) - (a.likeCount || 0));
        break;
      case 3: // 实惠：avgPrice 升序
        arr.sort((a, b) => (a.avgPrice || 999) - (b.avgPrice || 999));
        break;
      default:
        break;
    }
    return arr;
  },

  /** 给列表项补充展示字段 */
  decorateList(list) {
    return list.map((item, i) => ({
      ...item,
      rank: i + 1,
      img: item.img || item.image || item.banner || "",
      ratingStars: item.rating ? toStarsOnly(item.rating) : "",
      reviewCount: item.reviewCount || 0,
      likeCount: item.likeCount || 0,
      likeCountText: this.formatLikeCount(item.likeCount || 0),
      distance: item.distance || 0,
      avgPrice: item.avgPrice || 0,
      tags: item.tags || []
    }));
  },

  // ========= 跳转 =========

  goSearch() {
    wx.navigateTo({ url: "/pages/search/search" });
  },

  onLocation() {
    wx.showToast({ title: "定位功能开发中", icon: "none" });
  },

  goToDetail(e) {
    const item = e.currentTarget.dataset.item;
    if (item && item.id) {
      wx.navigateTo({ url: `/pages/stall/stall?id=${item.id}` });
    }
  },

  goMore() {
    wx.switchTab({ url: "/pages/nearby/nearby" });
  },

  /** 格式化距离 */
  formatDistance(m) {
    if (!m) return "";
    if (m < 1000) return m + "m";
    return (m / 1000).toFixed(1) + "km";
  },

  /** 格式化点赞数 */
  formatLikeCount(n) {
    if (!n) return "0";
    if (n >= 10000) return (n / 10000).toFixed(1) + "w";
    if (n >= 1000) return (n / 1000).toFixed(1) + "k";
    return String(n);
  }
});
