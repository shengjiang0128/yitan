const STORAGE_KEY = "yitan_stall_exposure";
const MAX_DAILY_LOG = 30; // 保留最近 30 天的每日数据

/** 读取全部曝光数据 */
function getAllExposure() {
  return wx.getStorageSync(STORAGE_KEY) || {};
}

/** 保存全部曝光数据 */
function saveAllExposure(data) {
  wx.setStorageSync(STORAGE_KEY, data);
}

/** 获取今日日期字符串 "YYYY-MM-DD" */
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** 初始化或获取某个摊位的曝光记录 */
function getOrInit(stallId) {
  const all = getAllExposure();
  const key = String(stallId);
  if (!all[key]) {
    all[key] = {
      totalViews: 0,
      todayViews: 0,
      todayDate: todayStr(),
      dailyLog: []
    };
  }
  return { all, entry: all[key] };
}

/** 检查并刷新今日计数（跨天自动归零） */
function refreshToday(entry) {
  const today = todayStr();
  if (entry.todayDate !== today) {
    // 把昨天数据归档到 dailyLog
    if (entry.todayViews > 0) {
      entry.dailyLog.unshift({ date: entry.todayDate, views: entry.todayViews });
      if (entry.dailyLog.length > MAX_DAILY_LOG) {
        entry.dailyLog = entry.dailyLog.slice(0, MAX_DAILY_LOG);
      }
    }
    entry.todayDate = today;
    entry.todayViews = 0;
  }
}

/**
 * 记录一次摊位浏览（食客打开摊位详情时调用）
 * @param {string|number} stallId
 */
function recordStallView(stallId) {
  if (stallId == null) return;
  const { all, entry } = getOrInit(stallId);
  refreshToday(entry);
  entry.totalViews += 1;
  entry.todayViews += 1;
  saveAllExposure(all);
}

/**
 * 获取单个摊位的曝光统计
 * @param {string|number} stallId
 * @returns {{totalViews:number, todayViews:number, weeklyViews:number, weeklyTrend:Array}}
 */
function getStallExposure(stallId) {
  const { all, entry } = getOrInit(stallId);
  refreshToday(entry);

  // 计算近 7 天总量
  const today = todayStr();
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const sevenDayStr = `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth() + 1).padStart(2, "0")}-${String(sevenDaysAgo.getDate()).padStart(2, "0")}`;

  let weeklyViews = 0;
  const weeklyTrend = [];

  // 生成近 7 天的趋势数据（从远到近）
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    let views = 0;
    if (dateKey === today) {
      views = entry.todayViews;
    } else {
      const found = entry.dailyLog.find((log) => log.date === dateKey);
      views = found ? found.views : 0;
    }
    weeklyTrend.push({
      date: dateKey,
      label: i === 0 ? "今天" : `${d.getMonth() + 1}/${d.getDate()}`,
      views
    });
    weeklyViews += views;
  }

  return {
    totalViews: entry.totalViews,
    todayViews: entry.todayViews,
    weeklyViews,
    weeklyTrend
  };
}

/**
 * 批量获取多个摊位的曝光统计（摊主端"我的摊位"使用）
 * @param {Array<{id:string|number}>} stalls
 * @returns {object} { [stallId]: exposureData }
 */
function getExposureMap(stalls) {
  const map = {};
  if (!stalls || !stalls.length) return map;
  for (const stall of stalls) {
    const id = String(stall.id);
    map[id] = getStallExposure(id);
  }
  return map;
}

module.exports = {
  recordStallView,
  getStallExposure,
  getExposureMap
};
