const { getProfile } = require("./profile.js");

const STORAGE_KEY = "yitan_stall_reviews";

// 评分维度权重
const SCORE_WEIGHTS = {
  taste: 0.40,    // 味道 40%
  service: 0.20,  // 服务 20%
  value: 0.20,    // 性价比 20%
  hygiene: 0.20   // 卫生 20%
};

// 可信评价门槛
const RELIABLE_THRESHOLD = 5;

function getAllReviews() {
  return wx.getStorageSync(STORAGE_KEY) || [];
}

function saveAllReviews(list) {
  wx.setStorageSync(STORAGE_KEY, list);
}

/**
 * 根据四维评分计算综合分（加权平均）
 * @param {{taste:number, service:number, value:number, hygiene:number}} scores
 * @returns {number} 综合分，保留 1 位小数
 */
function calcOverallRating(scores) {
  if (!scores || typeof scores !== "object") return 0;
  const taste = Number(scores.taste) || 0;
  const service = Number(scores.service) || 0;
  const value = Number(scores.value) || 0;
  const hygiene = Number(scores.hygiene) || 0;
  if (taste === 0 && service === 0 && value === 0 && hygiene === 0) return 0;
  const overall =
    taste * SCORE_WEIGHTS.taste +
    service * SCORE_WEIGHTS.service +
    value * SCORE_WEIGHTS.value +
    hygiene * SCORE_WEIGHTS.hygiene;
  return Math.round(overall * 10) / 10;
}

/**
 * 添加评价
 * @param {object} payload
 * @param {string} payload.stallId
 * @param {string} payload.stallName
 * @param {string} payload.stallCover
 * @param {string} payload.content
 * @param {string[]} payload.images
 * @param {{taste:number, service:number, value:number, hygiene:number}} payload.scores
 */
function addReview(payload) {
  const profile = getProfile();
  const {
    stallId,
    stallName,
    stallCover,
    content,
    images = [],
    scores = null
  } = payload || {};

  const review = {
    id: Date.now(),
    stallId: String(stallId),
    stallName: stallName || "小摊",
    stallCover: stallCover || "",
    content: (content || "").trim(),
    images: images.slice(0, 3),
    scores: scores
      ? {
          taste: Math.min(5, Math.max(1, Number(scores.taste) || 0)),
          service: Math.min(5, Math.max(1, Number(scores.service) || 0)),
          value: Math.min(5, Math.max(1, Number(scores.value) || 0)),
          hygiene: Math.min(5, Math.max(1, Number(scores.hygiene) || 0))
        }
      : null,
    overallRating: scores ? calcOverallRating(scores) : 0,
    authorNickname: profile.nickname,
    authorAvatar: profile.avatar,
    likeCount: 0,
    createdAt: new Date().toISOString()
  };

  const list = getAllReviews();
  list.unshift(review);
  saveAllReviews(list);
  return review;
}

function getReviewsByStallId(stallId) {
  const sid = String(stallId);
  return getAllReviews()
    .filter((item) => String(item.stallId) === sid)
    .sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
}

function getMyReviews() {
  const profile = getProfile();
  return getAllReviews()
    .filter((item) => item.authorNickname === profile.nickname)
    .sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
}

/**
 * 获取摊位的综合评分及各维度均分
 * @param {string|number} stallId
 * @returns {{
 *   overall: number,
 *   taste: number,
 *   service: number,
 *   value: number,
 *   hygiene: number,
 *   reviewCount: number,
 *   isReliable: boolean
 * }}
 */
function getStallRating(stallId) {
  const reviews = getReviewsByStallId(stallId);
  const scored = reviews.filter((r) => r.scores && r.overallRating > 0);

  if (scored.length === 0) {
    return {
      overall: 0,
      taste: 0,
      service: 0,
      value: 0,
      hygiene: 0,
      reviewCount: reviews.length,
      isReliable: false
    };
  }

  const sum = scored.reduce(
    (acc, r) => {
      acc.taste += r.scores.taste;
      acc.service += r.scores.service;
      acc.value += r.scores.value;
      acc.hygiene += r.scores.hygiene;
      acc.overall += r.overallRating;
      return acc;
    },
    { taste: 0, service: 0, value: 0, hygiene: 0, overall: 0 }
  );

  const n = scored.length;
  const round1 = (v) => Math.round(v * 10) / 10;

  return {
    overall: round1(sum.overall / n),
    taste: round1(sum.taste / n),
    service: round1(sum.service / n),
    value: round1(sum.value / n),
    hygiene: round1(sum.hygiene / n),
    reviewCount: reviews.length,
    scoredCount: n,
    isReliable: n >= RELIABLE_THRESHOLD
  };
}

/**
 * 将评分转为星级字符串
 * @param {number} rating 0-5
 * @returns {string} 如 "⭐⭐⭐⭐½"
 */
function toStarString(rating) {
  if (rating <= 0) return "暂无评分";
  const full = Math.floor(rating);
  const half = rating - full >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return "⭐".repeat(full) + (half ? "½" : "") + (empty > 0 ? " ☆".repeat(empty) : "");
}

/**
 * 将评分转为短星级（仅星星，无空星）
 * @param {number} rating
 * @returns {string} 如 "⭐⭐⭐⭐"
 */
function toStarsOnly(rating) {
  if (rating <= 0) return "";
  const full = Math.floor(rating);
  const half = rating - full >= 0.3 ? 1 : 0;
  return "⭐".repeat(full) + (half ? "½" : "");
}

function formatReviewDate(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const hh = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  return `${m}月${d}日 ${hh}:${mm}`;
}

module.exports = {
  addReview,
  getReviewsByStallId,
  getMyReviews,
  getStallRating,
  calcOverallRating,
  toStarString,
  toStarsOnly,
  formatReviewDate,
  SCORE_WEIGHTS,
  RELIABLE_THRESHOLD
};
